DOM Example
Canvas Example
